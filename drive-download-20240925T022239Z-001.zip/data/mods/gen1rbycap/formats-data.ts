export const FormatsData: import('../../../sim/dex-species').ModdedSpeciesFormatsDataTable = {
	corupcake: {
		tier: "OU",
	},
	gargoyle: {
		tier: "OU",
	},
	phantom: {
		tier: "OU",
	},
	mandrelec: {
		tier: "OU",
	},
	pineguin: {
		tier: "OU",
	},
};
