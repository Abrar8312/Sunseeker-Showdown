export const Scripts: ModdedBattleScriptsData = {
	inherit: 'gen1',
	gen: 1,
};
