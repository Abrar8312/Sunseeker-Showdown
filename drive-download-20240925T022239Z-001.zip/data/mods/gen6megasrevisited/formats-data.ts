export const FormatsData: import('../../../sim/dex-species').ModdedSpeciesFormatsDataTable = {
	blaziken: {
		tier: "OU",
	},
	blazikenmega: {
		tier: "OU",
	},
	gengarmega: {
		tier: "OU",
	},
	kangaskhanmega: {
		tier: "OU",
	},
	lucariomega: {
		tier: "OU",
	},
	mawilemega: {
		tier: "OU",
	},
	sableyemega: {
		tier: "OU",
	},
	salamencemega: {
		tier: "OU",
	},
};
