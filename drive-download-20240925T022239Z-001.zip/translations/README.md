# Translations

This directory contains translated strings for Pokémon Showdown. Each language has its own directory; the `english/` directory contains all the strings that can possibly be translated.

Each directory can contain multiple `.ts` files containing translated files; one of these files should specify the `name` attribute within the exported `translations` object, as well as the `strings` attribute.